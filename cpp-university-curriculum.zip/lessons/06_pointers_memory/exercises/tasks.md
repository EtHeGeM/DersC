# Pointers & Memory Exercises

Use this folder to explore manual memory management tasks. Keep ASAN builds handy to detect misuse.
