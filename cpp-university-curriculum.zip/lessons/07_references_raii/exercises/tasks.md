# References & RAII Exercises

Document ownership decisions for any additional RAII types you create during practice.
