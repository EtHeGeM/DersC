# Arrays & Strings Exercises

Use this folder for custom string and array experiments described in the module README.
