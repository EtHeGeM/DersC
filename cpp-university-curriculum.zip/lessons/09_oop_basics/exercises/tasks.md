# OOP Basics Exercises

Use this file to track class design tasks described in the README.
