#pragma once

#include <string>
#include <vector>

namespace lesson03 {
std::vector<std::string> fizzbuzz(int n);
int count_even(const std::vector<int> &values);
bool classify_temperature(int celsius);
}
