# Functions & Modularization Exercises

Use additional translation units to extend math helpers and practice header hygiene.
