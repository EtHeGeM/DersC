# Structs & Modeling Exercises

Extend the geometry models or design your own domain structs following the README prompts.
