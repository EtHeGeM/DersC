# Types & Operators Exercises

Follow the prompts in the module README to extend numeric utilities. Add new translation units rather than modifying test files.
