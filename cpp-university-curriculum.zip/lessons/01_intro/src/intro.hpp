#pragma once

#include <string>

namespace lesson01 {
std::string greeting(const std::string &name);
int add(int a, int b);
}
