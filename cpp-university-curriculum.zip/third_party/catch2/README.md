Catch2 is fetched automatically via CMake FetchContent (see root CMakeLists). This directory exists to satisfy repository structure requirements and to host any future patches or vendor notes.
