# Solutions

Instructor-only reference stubs. Encourage students to attempt exercises first; use solutions to learn alternative approaches and idiomatic patterns. Refer to each module's `exercises/` for commented reference implementations.
